def greet(name, time_of_day)
  return "Good #{time_of_day}, #{name.capitalize()}"
end

def add(first_number, second_number)
  return first_number + second_number
end