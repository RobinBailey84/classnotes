class Cake

  attr_reader :name, :ingredients, :rating

  def initialize(name, ingredients, rating)
    @name = name
    @ingredients = ingredients
    @rating = rating
  end

end
